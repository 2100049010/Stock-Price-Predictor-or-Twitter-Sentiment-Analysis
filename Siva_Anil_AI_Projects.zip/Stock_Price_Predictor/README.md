# Stock Price Predictor
This project uses Linear Regression to predict stock prices based on historical data.

## Technologies Used
- Python
- Pandas
- Scikit-learn
- Matplotlib

## Features
- Data cleaning and visualization
- Predictive modeling using Linear Regression
- Evaluation using R² and MSE

## Dataset
Historical stock data from Yahoo Finance (CSV format).