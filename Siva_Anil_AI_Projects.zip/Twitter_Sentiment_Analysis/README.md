# Sentiment Analysis on Twitter Data
This project classifies tweets as Positive, Negative, or Neutral using NLP techniques.

## Technologies Used
- Python
- Tweepy
- NLTK
- TextBlob
- Matplotlib, Seaborn

## Features
- Tweet collection using Twitter API
- Text preprocessing with NLTK
- Sentiment classification using TextBlob
- Sentiment visualization

## Dataset
Live tweets via Tweepy API.